
import { useEffect, useState } from "react";

function App(){
  const [assignments,setAssignments]=useState([]);
  const [query,setQuery]=useState("");
  const [result,setResult]=useState(null);

  useEffect(()=>{
    fetch("http://localhost:5000/api/assignments")
      .then(r=>r.json()).then(setAssignments);
  },[]);

  const runQuery=()=>{
    fetch("http://localhost:5000/api/execute",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({query})
    }).then(r=>r.json()).then(setResult);
  }

  return (
    <div>
      <h1>CipherSQLStudio</h1>
      <ul>
        {assignments.map(a=><li key={a.id}>{a.title} - {a.difficulty}</li>)}
      </ul>
      <textarea value={query} onChange={e=>setQuery(e.target.value)} />
      <button onClick={runQuery}>Execute</button>
      <pre>{JSON.stringify(result,null,2)}</pre>
    </div>
  )
}
export default App;
