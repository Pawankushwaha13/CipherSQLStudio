
import express from "express";
import cors from "cors";
import pkg from "pg";
import dotenv from "dotenv";

dotenv.config();
const { Pool } = pkg;
const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({ connectionString: process.env.POSTGRES_URL });

app.get("/api/assignments", async (req,res)=>{
  res.json([{
    id:1,
    title:"Employee Salary",
    difficulty:"Easy",
    description:"Find employees with salary > 50000",
    question:"Write a query to fetch employees having salary > 50000"
  }]);
});

app.post("/api/execute", async (req,res)=>{
  try{
    const { query } = req.body;
    const result = await pool.query(query);
    res.json(result.rows);
  }catch(e){
    res.status(400).json({error:e.message});
  }
});

app.post("/api/hint", async (req,res)=>{
  res.json({hint:"Think about WHERE clause and comparison operators."});
});

app.listen(5000, ()=>console.log("Backend running on 5000"));
